from app.app import create_app, socketio

app = create_app()

if __name__ == '__main__':
    port = 8888
    print(f"[*] ShellHub v1 iniciando en http://0.0.0.0:{port}")
    socketio.run(app, host='0.0.0.0', port=port, debug=True)
