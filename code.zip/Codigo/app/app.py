import os
from flask import Flask
from flask_socketio import SocketIO
from flask_login import LoginManager
from app.models import User, init_db
from app.manager import host_manager
from app.config import Config

socketio = SocketIO(async_mode='threading', cors_allowed_origins="*")

def create_app():
    app = Flask(__name__, 
                template_folder='templates',
                static_folder='static')
    
    # Secure persistent secret key
    app.config['SECRET_KEY'] = Config.get_secret_key()
    
    socketio.init_app(app)
    
    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'main.login'
    
    @login_manager.user_loader
    def load_user(user_id):
        return User.get(user_id)
    
    from app.routes import main_bp
    app.register_blueprint(main_bp)
    
    # Initialize host manager with socketio
    host_manager.set_socketio(socketio)
    
    # Initialize database
    init_db()
    
    # Create default user if not exists (using hashed credentials)
    if not User.find_by_username(Config.DEFAULT_USER):
        User.create(Config.DEFAULT_USER, Config.DEFAULT_PASS_HASH, is_hash=True)
        print(f"[+] Usuario '{Config.DEFAULT_USER}' inicializado")
            
    return app
