from flask import Blueprint, render_template, redirect, url_for, request, jsonify, flash
from flask_login import login_user, logout_user, login_required, current_user
from flask_socketio import emit, join_room, leave_room
from app.models import User
from app.manager import host_manager
import psutil

main_bp = Blueprint('main', __name__)

# ──────────────────────────── Pages ────────────────────────────────────

@main_bp.route('/')
@login_required
def dashboard():
    return render_template('dashboard.html', username=current_user.username)


@main_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.find_by_username(username)
        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for('main.dashboard'))
        flash('Credenciales inválidas')
    return render_template('login.html')


@main_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('main.login'))


@main_bp.route('/terminal/<identifier>')
@login_required
def terminal(identifier):
    # Special case: MASTER local shell
    if identifier == 'MASTER':
        shell_id = host_manager.start_master_shell()
        return render_template('terminal.html', shell_id=shell_id, identifier=identifier, mode='master')

    if identifier not in host_manager.hosts:
        flash('Dispositivo no encontrado')
        return redirect(url_for('main.dashboard'))

    host = host_manager.hosts[identifier]
    if not host.get('is_online'):
        flash('El dispositivo está fuera de línea')
        return redirect(url_for('main.dashboard'))

    shell_id = host.get('shell_id')
    mode = host.get('mode', 'raw')
    return render_template('terminal.html', shell_id=shell_id, identifier=identifier, mode=mode)


# ──────────────────────────── API ──────────────────────────────────────

@main_bp.route('/api/master_terminal', methods=['GET', 'POST'])
@login_required
def master_terminal():
    """Start (or reuse) the local host shell."""
    shell_id = host_manager.start_master_shell()
    return jsonify({'shell_id': shell_id, 'redirect': f'/terminal/MASTER'})


@main_bp.route('/api/health')
@login_required
def health():
    cpu  = psutil.cpu_percent()
    ram  = psutil.virtual_memory().percent
    disk = psutil.disk_usage('/').percent
    return jsonify({'cpu': cpu, 'ram': ram, 'disk': disk, 'hosts': len(host_manager.hosts)})


@main_bp.route('/api/toggle_listener', methods=['POST'])
@login_required
def toggle_listener():
    data = request.get_json() or {}
    try:
        port = int(data.get('port', 7777))
    except (ValueError, TypeError):
        port = 7777

    if host_manager.is_running and host_manager.port == port:
        host_manager.stop_listener()
        return jsonify({'status': 'stopped', 'active': False})
    else:
        success = host_manager.start_listener(port)
        return jsonify({'status': 'started' if success else 'failed', 'active': success, 'port': port})


@main_bp.route('/api/toggle_freeze/<identifier>', methods=['POST'])
@login_required
def toggle_freeze(identifier):
    new_state = host_manager.toggle_freeze(identifier)
    return jsonify({'frozen': new_state})


@main_bp.route('/api/kill/<identifier>', methods=['POST'])
@login_required
def kill_host(identifier):
    success = host_manager.kill_host(identifier)
    return jsonify({'success': success})


# ──────────────────────────── WebSocket Events ─────────────────────────

from app.app import socketio
from flask_socketio import disconnect


@socketio.on('connect', namespace='/panel')
def panel_connect():
    if not current_user.is_authenticated:
        return False
    emit('shell_list_update', host_manager.get_shell_list())


@socketio.on('connect', namespace='/shell')
def shell_connect():
    if not current_user.is_authenticated:
        return False


@socketio.on('join_shell', namespace='/shell')
def on_join_shell(data):
    if not current_user.is_authenticated:
        return disconnect()
    shell_id = data.get('shell_id')
    if shell_id in host_manager.shell_map or shell_id == 'MASTER':
        join_room(shell_id)
        emit('joined', {'shell_id': shell_id})


@socketio.on('shell_input', namespace='/shell')
def on_shell_input(data):
    if not current_user.is_authenticated:
        return disconnect()
    host_manager.send_input(data.get('shell_id', ''), data.get('data', ''))


@socketio.on('terminal_resize', namespace='/shell')
def on_terminal_resize(data):
    if not current_user.is_authenticated:
        return disconnect()
    host_manager.resize_terminal(data.get('shell_id', ''), data.get('cols', 80), data.get('rows', 24))


# ── Latency ping/pong for the terminal header indicator ──
@socketio.on('ping_latency', namespace='/shell')
def on_ping_latency(data):
    if not current_user.is_authenticated:
        return disconnect()
    emit('pong_latency', data)
