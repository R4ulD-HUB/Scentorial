import os
import secrets

class Config:
    SECRET_KEY_PATH = '.secret_key'
    
    @classmethod
    def get_secret_key(cls):
        if os.path.exists(cls.SECRET_KEY_PATH):
            with open(cls.SECRET_KEY_PATH, 'r') as f:
                return f.read().strip()
        
        new_key = secrets.token_hex(32)
        with open(cls.SECRET_KEY_PATH, 'w') as f:
            f.write(new_key)
        return new_key

    DEFAULT_USER = "gstxx"
    DEFAULT_PASS_HASH = "scrypt:32768:8:1$JXMLSw4g9ah8h46s$5aa326df0d5e2cc8441c9cc56ada90950ee6180f5622c05d8c183bb9ed9aaad1cb7376fcc34395594de04074d6c5791a26293cde2129fb6918cc50f9e3beae96"
